test = {
  'name': 'Question',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> len(dfparq)
          236
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> len(dfparq.columns)
          46
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
